# THREE.JS Blender exporter

Since the Blender exporter has been removed from THREE.JS (cf [https://github.com/mrdoob/three.js/tree/dev/utils/exporters/blender](https://github.com/mrdoob/three.js/tree/dev/utils/exporters/blender)), we have add it here.

Indeed, we use it in our demonstrations and tutorials. Just copy the `io_three` directory in `<blender_path>/scripts/`, then restart Blender and enable it in `File/user preferences`.

We do not maintain this code, we did not bring any modification to it and we do not provide any support for it.
