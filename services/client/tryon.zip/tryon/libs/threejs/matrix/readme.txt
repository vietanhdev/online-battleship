This is a part of the Math part of THREE.js 
