# Glasses Virtual Try On

- This repo was initialized using `miel_pops` example of FaceFilter library: [https://github.com//FaceFilter/tree/master/demos/threejs/miel_pops](https://github.com//FaceFilter/tree/master/demos/threejs/miel_pops).